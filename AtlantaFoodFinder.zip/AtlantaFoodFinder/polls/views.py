from django.db.models import F
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import generic
from django.utils import timezone
from django.http import HttpResponse
class landingPage(generic.ListView):
    template_name = "Home/landingPage.html"

def landingPage(request):
    #return HttpResponse("Hi! i hate cs")
    return render(request, 'Home/landingPage.html')