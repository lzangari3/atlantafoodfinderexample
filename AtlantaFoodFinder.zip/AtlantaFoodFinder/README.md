# AtlantaFoodFinder
Atlanta Food Finder is a web app that allows users to search for and discover restaurants in Atlanta
